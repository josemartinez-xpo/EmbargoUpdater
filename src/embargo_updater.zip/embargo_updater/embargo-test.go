package main

import (
	"fmt"
)

func main() {

	fmt.Println("Requesting token...")
	token := RequestToken()

	fmt.Println("Requesting embargo info...")
	embargo_info := RequestEmbargo(token)

	fmt.Println("Parsing json...")
	embargoItems, err := ParseEmbargoResponse(embargo_info)
	if err != nil {
		panic(err)
	}

	fmt.Println("Creating csv...")
	err = CreateCSV(embargoItems, "xpo-embargo-freezable.csv")
	
	fmt.Println("Done!")
}